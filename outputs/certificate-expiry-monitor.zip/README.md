# Certificate Expiry Monitor

`certificate-expiry-monitor` checks remote TLS leaf certificates and local PEM/DER certificate files, evaluates their remaining lifetime in UTC, and alerts only on a new more-severe tier. It is designed for cron, CI, and small operational monitoring jobs.

## Installation

Python 3.11 or later is required.

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Usage

```bash
python -m checker --help
python -m checker --config example_config.yaml
python -m checker --domain example.com:443 --domain api.example.com:443
python -m checker --file ./certificates/server.pem
python -m checker --format json --domain example.com:443
python -m checker --format prometheus --config example_config.yaml
python -m checker --dry-run --config example_config.yaml
python -m checker --force-notify --config example_config.yaml
```

Remote targets accept `host:port` and `[ipv6-address]:port`. File targets accept an individual `.pem`, `.crt`, `.cer`, or `.der` file, a glob, or a directory. Directory scans are non-recursive and skip unrelated file extensions. A candidate certificate file that is malformed is reported as an `ERROR`; it is never silently treated as healthy.

CLI targets are appended to targets in the config file. Explicit `--timeout`, `--concurrency`, and `--state-file` flags override the configured settings.

## Configuration

Copy and adapt [example_config.yaml](example_config.yaml). YAML and JSON are supported. `${NAME}` within any string is replaced with the `NAME` environment variable, which is useful for a webhook URL:

```bash
export CERT_WEBHOOK_URL='https://hooks.example.invalid/monitor'
python -m checker --config example_config.yaml
```

The tool never writes the webhook URL to logs. The console notifier writes alerts to stderr so that JSON and Prometheus output on stdout remain machine-readable.

## Output

Table output:

```text
TARGET               STATUS   DAYS  EXPIRES                  CHAIN
example.com:443      OK       82    2026-10-17T12:00:00Z     true
api.example.com:443  WARNING  27    2026-08-23T12:00:00Z     true
old.example.com:443  EXPIRED  -3    2026-07-24T12:00:00Z     false
```

JSON output:

```json
[
  {
    "target": "api.example.com:443",
    "status": "WARNING",
    "days_remaining": 27,
    "expires_at": "2026-08-23T12:00:00Z",
    "reason_code": null
  }
]
```

Prometheus output includes `certificate_days_remaining`, `certificate_severity`, `certificate_chain_valid`, and `certificate_check_error` gauges. It uses a `target` label, so keep the configured target set bounded.

## Severity and time behavior

All certificate times and comparisons use aware UTC datetimes. Days are calculated exactly as `floor((not_after - now) / one day)`.

| Days remaining | Severity |
|---:|---|
| `< 0` | `EXPIRED` |
| `<= 5` | `CRITICAL` |
| `<= 15` | `HIGH` |
| `<= 30` | `WARNING` |
| `> 30` | `OK` |

The three non-expired thresholds are configurable. Certificates whose `not_before` time is in the future are `CRITICAL`: they are currently unusable even if their expiry is distant.

For TLS, the tool first retrieves the leaf with a scoped unverified connection, allowing expired and self-signed certificates to be inspected. It separately attempts ordinary platform chain validation and reports `chain_valid` as `true`, `false`, or `null` when it cannot be determined.

## Alerts, state, and suppressions

State is a portable JSON file, `.certificate-monitor-state.json` by default. Its alert key is the target plus the SHA-256 certificate fingerprint. A target is alerted when a certificate enters `WARNING`, then only when that same certificate escalates to `HIGH`, `CRITICAL`, or `EXPIRED`. A replacement certificate has a different fingerprint and naturally begins a fresh alert history.

`--force-notify` bypasses tier deduplication but does not reset state. `--dry-run` performs checks and reports would-be alerts on stderr, but neither sends alerts nor writes state.

Suppressions affect notifications only; checks and their results remain visible. A bare target suppresses every certificate at that target; adding a fingerprint scopes it to one certificate.

```bash
python -m checker suppress --target api.example.com:443 --reason "planned rotation"
python -m checker acknowledge --target api.example.com:443 --fingerprint 0123abcd --until 2026-09-01T00:00:00Z
python -m checker unsuppress --target api.example.com:443
```

`acknowledge` is an alias of `suppress`. `--until` must include a timezone and is optional.

## Exit codes

| Code | Meaning |
|---:|---|
| 0 | Every target is `OK`, or there are no targets. |
| 1 | At least one `WARNING` or `HIGH` result, and no `CRITICAL` or `EXPIRED` result. |
| 2 | At least one `CRITICAL` or `EXPIRED` result. |
| 3 | A per-target `ERROR` or tool-level configuration/state/notification failure, unless a severity exit code 1 or 2 takes precedence. |

Per-target errors, such as DNS failures, connection refusal, timeout, handshake failure, malformed files, and permission denial, do not abort checks for other targets.

## Automation examples

Cron:

```cron
17 * * * * /opt/certificate-monitor/.venv/bin/python -m checker --config /etc/certificate-monitor/config.yaml --quiet >> /var/log/certificate-monitor.log 2>&1
```

`/etc/systemd/system/certificate-monitor.service`:

```ini
[Unit]
Description=Certificate expiry monitor

[Service]
Type=oneshot
WorkingDirectory=/opt/certificate-monitor
ExecStart=/opt/certificate-monitor/.venv/bin/python -m checker --config /etc/certificate-monitor/config.yaml
```

`/etc/systemd/system/certificate-monitor.timer`:

```ini
[Unit]
Description=Run certificate expiry monitor hourly

[Timer]
OnCalendar=hourly
Persistent=true

[Install]
WantedBy=timers.target
```

Enable it with `systemctl enable --now certificate-monitor.timer`.

GitHub Actions (`.github/workflows/certificates.yml`):

```yaml
name: certificates
on:
  schedule:
    - cron: "17 * * * *"
  workflow_dispatch:
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: pip install -r requirements.txt
      - run: python -m checker --config example_config.yaml --format table
        env:
          CERT_WEBHOOK_URL: ${{ secrets.CERT_WEBHOOK_URL }}
```

## Testing

```bash
pytest
```

The suite generates all X.509 fixtures at test time, so no expiring test certificates are committed. It covers UTC-aware calculations and exact boundaries, not-yet-valid certificates, metadata parsing, local-source errors, TLS error mapping without network access, concurrent failure isolation, notifier payloads, state escalation/deduplication, suppressions, force notification, output formats, and exit-code selection.

## Design decisions and limitations

The evaluation layer is pure: sources turn I/O into `CertInfo` or error results, then evaluation receives a clock and thresholds. This makes the tier logic deterministic and straightforward to test. A thread pool is used because checks are network/file I/O bound and each source has an independent timeout. JSON state is intentionally simple and easy to inspect; the atomic replacement write avoids partially written state in ordinary single-process use.

Current limitations:

- Only direct TLS and local PEM/DER sources are implemented; SMTP/IMAP STARTTLS and PKCS#12 are future extensions through the source interface.
- TLS chain diagnostics are limited to an independent validation verdict rather than a full chain report.
- The JSON state backend is intended for one monitor process at a time; a shared multi-host deployment should use a locking/database backend.
- Future integrations could add grouped alerts, email/PagerDuty, certificate-transparency monitoring, OCSP/CRL status, and Kubernetes discovery.
